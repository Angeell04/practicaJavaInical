package data;

import models.*;

public class Data {
    // 1. Generar inventario inicial con productos físicos y digitales
    public static Inventario generarInventarioMock() {
        Inventario inventario = new Inventario();

        // Constructor ProductoFisico: (float peso, float gastosEnvio, int id, String nombre, float precio, int stock)
        inventario.addProductoFisico(new ProductoFisico(1.5f, 4.99f, 1, "Camiseta Casual", 19.99f, 10));
        inventario.addProductoFisico(new ProductoFisico(0.4f, 2.99f, 2, "Ratón Inalámbrico", 25.50f, 5));

        // Constructor ProductoDigital: (String licencia, float tamanioDescarga, int id, String nombre, float precio, int stock)
        inventario.addProductoDigital(new ProductoDigital("MIT", 150.0f, 3, "Antivirus Pro 2026", 39.99f, 100));
        inventario.addProductoDigital(new ProductoDigital("GPL", 450.5f, 4, "Curso de Java Avanzado", 49.99f, 50));

        return inventario;
    }

    // 2. Generar gestión de usuarios inicial
    public static GestionUsuarios generarGestionUsuariosMock() {
        GestionUsuarios gestion = new GestionUsuarios();

        // Constructor Usuario: (String password, int id, String nombre, String email, boolean activo)
        gestion.addUsuario(new Usuario("1234", 1, "Angel Miranda", "angel@gmail.com", true));
        gestion.addUsuario(new Usuario("admin", 2, "Admin", "admin", true));

        return gestion;
    }

    // 3. Generar historial de pedidos vacío (o con datos si lo deseas)
    public static HistorialPedidos generarHistorialMock() {
        HistorialPedidos historial = new HistorialPedidos();
        // El historial empieza vacío por defecto
        return historial;
    }
}
