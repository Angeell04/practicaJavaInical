package persistencia;

import models.GestionUsuarios;
import models.HistorialPedidos;
import models.Inventario;

import java.io.*;

public class Persistencia {
    public static Inventario leeInventario() {
        FileInputStream fis = null;
        Inventario o = null;
        try{
            fis = new FileInputStream("src/data/inventario.bin");
            ObjectInputStream ois = new ObjectInputStream(fis);
            o = (Inventario) ois.readObject();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return o;
    }


    public static boolean guardaInventario(Inventario inventario) {
        ObjectOutputStream oos = null;
        try{
            FileOutputStream fis = new FileOutputStream("src/data/inventario.bin");
            oos = new ObjectOutputStream(fis);
            oos.writeObject(inventario);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }


    public static GestionUsuarios leeGestionUsuarios(){
        FileInputStream fis = null;
        GestionUsuarios o = null;
        try{
            fis = new FileInputStream("src/data/gestion.bin");
            ObjectInputStream ois = new ObjectInputStream(fis);
            o = (GestionUsuarios) ois.readObject();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return o;
    }

    public static boolean guardaGestionUsuarios(GestionUsuarios gestionUsuarios){
        ObjectOutputStream oos = null;
        try{
            FileOutputStream fis = new FileOutputStream("src/data/gestion.bin");
            oos = new ObjectOutputStream(fis);
            oos.writeObject(gestionUsuarios);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public static HistorialPedidos leeHistorialPedidos(){
        FileInputStream fis = null;
        HistorialPedidos o = null;
        try{
            fis = new FileInputStream("src/data/historial.bin");
            ObjectInputStream ois = new ObjectInputStream(fis);
            o = (HistorialPedidos) ois.readObject();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return o;
    }

    public static boolean guardaHistorialPedidos(HistorialPedidos historialPedidos){
        ObjectOutputStream oos = null;
        try{
            FileOutputStream fis = new FileOutputStream("src/data/historial.bin");
            oos = new ObjectOutputStream(fis);
            oos.writeObject(historialPedidos);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

}
