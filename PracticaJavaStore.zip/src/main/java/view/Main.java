package view;

import controller.Controller;
import models.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Main {
    public final static Scanner sc = new Scanner(System.in);
    public final static Controller controller = new Controller();
    public static void pulsaParaContinuar() {
        System.out.print("Pulsa cualquier tecla para continuar: ");
        sc.nextLine();
    }

    public static void limpiaPantallas(){
        for (int i = 0; i < 100; i++){
            System.out.println();
        }
    }
    public static void main(String[] args) {

        runApp();
    }

    public static void runApp() {
        int op = 0;
        try{
            do {
                System.out.print("""
                Bienvenido a la APP de gestion de Inventario.
                    1. Login.
                    2. Registro.
                    3. Invitado.
                    4. Cerrar app.
                    Introduce una opción correcta:\s""");
                op = Integer.parseInt(sc.nextLine());
                switch (op) {
                    case 1:
                        login();
                        break;
                    case 2:
                        registro();
                        break;
                    case 3:
                        invitado();
                        break;
                    case 4:
                        System.out.println("Saliendo de la app.");
                        break;
                    default:
                        System.out.println("La opción seleccionada no es correcta");
                }
            }while (op != 4);
        }catch (NumberFormatException e){
            System.out.println("Debes introducir un número");
        }
    }

    public static void login() {
        int intentos = 0;
        String password, usuario;
        boolean valido = false;

        do {
            System.out.println("======= Login ======");
            System.out.print("Email: ");
            usuario = sc.nextLine();
            System.out.print("Contraseña: ");
            password = sc.nextLine();
            intentos++;
            valido = controller.login(usuario, password);
            if (!valido){
                System.out.println("Te has equivocado en el usuario o la contraseña.");
                System.out.println("Te quedan " + (3 - intentos) + " intentos");
            }
        }while (intentos < 3 && !valido);
        if (intentos < 3 && !controller.logAdmin(usuario, password)){
            pulsaParaContinuar();
            limpiaPantallas();
            menuPrincipalApp();

        }
        else if (intentos < 3 && controller.logAdmin(usuario, password)) {
            pulsaParaContinuar();
            limpiaPantallas();
            menuAdmin();
        } else {
            System.out.println("Has perdido todos los intentos :(\n Redirigiendo al menu principal.");
        }
        pulsaParaContinuar();
        limpiaPantallas();
    }

    private static void menuAdmin() {
        int op = 0;
        do {
            try{
                System.out.print("""
                        ========== Bienvenido al menú admin ==========
                            1. Ver pedidos.
                            2. Introducir un producto.
                            3. Quitar un producto.
                            4. Salir.
                            Introduce una opción válida:\s""");
                op = Integer.parseInt(sc.nextLine());
            }catch (NumberFormatException e){
                System.out.println("Debes introducir un número");
            }
            switch (op){
                case 1:
                    limpiaPantallas();
                    verPedidos();
                    pulsaParaContinuar();
                    limpiaPantallas();
                    break;
                case 2:
                    limpiaPantallas();
                    introducirProducto();
                    pulsaParaContinuar();
                    limpiaPantallas();
                    break;
                case 3:
                    limpiaPantallas();
                    quitarProducto();
                    pulsaParaContinuar();
                    limpiaPantallas();
                    break;
                case 4:
                    System.out.println("Saliendo al login.");
                    break;
            }

        }while (op != 4);
    }

    private static void quitarProducto() {
        System.out.println("=========== Quitar producto ==========");
        verProductosDigitales();
        System.out.println();
        verProductosFisicos();

        System.out.print("Que producto quieres quitar: ");
        String producto = sc.nextLine();
        if (controller.quitaProductoInventatirio(producto)) System.out.println("Se ha podido quitar el producto correctamete.");
        else System.out.println("No se ha podido quitar el producto correctamete.");
    }

    private static void introducirProducto() {
        int op = 0;
        do {
            try {
                System.out.print("""
                    ============= Introducir producto =============
                        1. Producto Digital.
                        2. Producto Físico.
                        3. Salir
                        Introduce una opción válida:\s""");
                op = Integer.parseInt(sc.nextLine());
            }catch (NumberFormatException e){
                System.out.println("Debes introducir un número.");
            }
            switch (op){
                case 1:
                    introduceProductoDigital();
                    break;
                case 2:
                    introducriProductoFisico();
                    break;
                case 3:
                    System.out.println("Saliendo al menu admin.");
                    break;
            }
            pulsaParaContinuar();
            limpiaPantallas();
        }while (op != 3);
    }

    private static void introducriProductoFisico() {
        System.out.println("Bienvenido a Introducir un producto Físico1!");
        try {
            System.out.print("Dime el nombre del producto: ");
            String nombre = sc.nextLine();
            System.out.print("Dime el precio del producto: ");
            float precio = Float.parseFloat(sc.nextLine());
            System.out.print("Dime el stock del producto: ");
            int stock = Integer.parseInt(sc.nextLine());
            System.out.print("Dime el peso del producto: ");
            float peso = Float.parseFloat(sc.nextLine());
            System.out.print("Dime los gastos de envío: ");
            float gastos =  Float.parseFloat(sc.nextLine());

            if (controller.introducirProductoFisico(peso, gastos,nombre,precio,stock)) System.out.println("Se ha subido correctamente");
            else System.out.println("No se ha podido subir el producto");
        }catch (NumberFormatException e){
            System.out.println("Debes introducir un número");
        }
    }

    private static void introduceProductoDigital() {
        System.out.println("Bienvenido a Introducir un producto digital!");
        try {
            System.out.print("Dime el nombre del producto: ");
            String nombre = sc.nextLine();
            System.out.print("Dime el precio del producto: ");
            float precio = Float.parseFloat(sc.nextLine());
            System.out.print("Dime las copias que quieres vender del producto: ");
            int stock = Integer.parseInt(sc.nextLine());
            System.out.print("Dime la Licencia del producto: ");
            String licencia = sc.nextLine();
            System.out.print("Dime el tamaño de la descarga (MB/GB): ");
            float tamanio =  Float.parseFloat(sc.nextLine());

            if (controller.introducirProductoDigital(licencia, tamanio,nombre,precio,stock)) System.out.println("Se ha subido correctamente");
            else System.out.println("No se ha podido subir el producto");
        }catch (NumberFormatException e){
            System.out.println("Debes introducir un numero.");
        }
    }

    private static void verPedidos() {
        System.out.println("======= Pedidos de usuarios =======");
        for (Pedido pedido: controller.verPedidos()){
            System.out.println(pedido.toString());
            System.out.println("\n \n\n");
        }
    }

    public static void registro() {
        System.out.println("======= Registro ======");
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Email: ");
        String email = sc.nextLine();
        System.out.print("Contraseña: ");
        String password = sc.nextLine();
        if (controller.registro(nombre, email, password)){
            pulsaParaContinuar();
            limpiaPantallas();
            menuPrincipalApp();
        }
        else{
            System.out.println("Algo ha ido mal :( \n Redirigiendo al menu principal.");
            pulsaParaContinuar();
            limpiaPantallas();
        }
    }

    public static void invitado() {
        int op = 0;
        try {
            do {
                System.out.print("""
                ======= Invitado ======
                Solo está permitido que veas los productos pero no podrás interactuar con ellos
                    1. Ver productos digitales.
                    2. Ver productos físicos.
                    3. Salir.
                    Introduce una opción correcta:\s""");
                op = Integer.parseInt(sc.nextLine());
                switch (op) {
                    case 1:
                        limpiaPantallas();
                        verProductosDigitales();
                        break;
                    case 2:
                        limpiaPantallas();
                        verProductosFisicos();
                        break;
                    case 3:
                        System.out.println("Saliendo al menu principal.");
                        pulsaParaContinuar();
                        limpiaPantallas();
                        break;
                    default:
                        System.out.println("La opción introducida no es correcta");
                        pulsaParaContinuar();
                        limpiaPantallas();
                }
            }while (op != 3);
        }catch (NumberFormatException e) {
            System.out.println("Debes introducir un número");
        }


    }

    private static void verProductosFisicos() {
        System.out.println("=============== Productos Físicos ===============");
        for (ProductoFisico producto : controller.verProductosFisicos()){
            System.out.println("Nombre: " + producto.getNombre());
            System.out.println("Precio: " + producto.getPrecio());
            System.out.println("Gastos envío: " + producto.getGastosEnvio());
            System.out.println("Peso: " + producto.getPeso());
            System.out.println("*******************************************************");
        }
    }

    private static void verProductosDigitales() {
        System.out.println("=============== Productos digitales ===============");
        for (ProductoDigital producto : controller.verProductosDigitales()){

            System.out.println("Nombre: " + producto.getNombre());
            System.out.println("Precio: " + producto.getPrecio());
            System.out.println("Licencia: " + producto.getLicencia());
            System.out.println("Tamaño descarga: " + producto.getTamanioDescarga());
            System.out.println("*******************************************************");
        }
    }

    public static void menuPrincipalApp() {
        int op = 0;
        do {
            try{
                System.out.print("""
                ========= Menu =========
                    1.Gestionar usuario.
                    2.Gestionar productos.
                    3.Gestionar carrito.
                    4.Cerrar pedido.
                    5.Ver mis pedidos
                    6.Volver al menu principal.
                    Introduce una opción correcta:\s""");
                op = Integer.parseInt(sc.nextLine());
            }catch (NumberFormatException e){
                System.out.println("Debes introducir un número");
            }
            switch (op) {
                case 1:
                    limpiaPantallas();
                    gestionUsuario();
                    break;
                case 2:
                    limpiaPantallas();
                    gestionProductos();
                    break;
                case 3:
                    limpiaPantallas();
                    gestionCarrito();
                    break;
                case 4:
                    limpiaPantallas();
                    cerrarPedido();
                    break;
                case 5:
                    limpiaPantallas();
                    verMisPedidos();
            }
        }while (op != 6);

    }

    private static void verMisPedidos() {
        for (Pedido pedidos : controller.verPedidosUsuario()){
            System.out.println(pedidos.toString());
        }
    }

    public static void cerrarPedido() {

        Pedido pedido = controller.cierraPedido();
        if (pedido != null) {
            System.out.println(pedido.toString());
        } else {
            List<Producto> productos = controller.obtenerProductosSinStock();
            if (productos.isEmpty()){
                System.out.println("Algo no ha ido bien");
            }
            else {
                verProductosSinStock(productos);
                quitaProductos(productos);
            }
        }
    }

    private static void quitaProductos(List<Producto> productos) {
        System.out.println("Quieres que los quitemos, o prefieres quitarlos tú manualmente? S/N");
        String opcion = sc.nextLine();

        switch (opcion.toUpperCase()) {
            case "S":
                for (Producto producto : productos) {
                    if (controller.quitaProductoCarrito(producto.getNombre()))
                        System.out.println(producto.getNombre() + " se ha quitado correctamente");
                    else System.out.println(producto.getNombre() + " no se ha podido quitar correctamente");
                }
                pulsaParaContinuar();
                limpiaPantallas();
                break;
            case "N":
                System.out.println("Saliendo al menú anterior");
                pulsaParaContinuar();
                limpiaPantallas();
                break;
            default:
                System.out.println("La opción introducida no es válida.");
                pulsaParaContinuar();
                limpiaPantallas();
        }
    }

    private static void verProductosSinStock(List<Producto> productos) {
        System.out.println("Estos productos no tienen stock: ");
        for (Producto producto : productos) {
            System.out.println(producto.getNombre() + " - " + producto.getPrecio());
        }
    }

    public static void gestionUsuario() {
        int op = 0;
        do {
            try{
                System.out.print("""
                ======== Bienvenido a la gestion de usuario ========
                    1.Ver datos personales.
                    2.Dar de baja.
                    3.Ver el listado de usuarios activos en este momento.
                    4.Salir al menú principal
                    Elige una opción correcta:\s""");
                op = Integer.parseInt(sc.nextLine());
            }catch (NumberFormatException e){
                System.out.println("Debes introducir un número");
            }
            switch (op) {
                case 1:
                    pintaDatosPersonales();
                    break;
                case 2:
                    controller.darDeBaja();
                    System.out.println("Se ha dado de baja correctamente");
                    pulsaParaContinuar();
                    limpiaPantallas();
                    break;
                case 3:
                    verListadoUsuariosActivos();
                    break;
                case 4:
                    System.out.println("Saliendo al menú principal de la app");
                    pulsaParaContinuar();
                    limpiaPantallas();
                    break;
                default:
                    System.out.println("La opción introducida no es correcta");
                    pulsaParaContinuar();
                    limpiaPantallas();
            }
        }while (op != 4);
    }

    public static void verListadoUsuariosActivos() {
        ArrayList<Usuario> usuarios = controller.traeUsuariosActivos();
        System.out.println("====== Usuarios activos: ======");
        for (Usuario usuario : usuarios) {
            System.out.println("Nombre: " + usuario.getNombre());
            System.out.println("Email: " + usuario.getEmail());
            System.out.println("*******************************");
        }
        pulsaParaContinuar();
        limpiaPantallas();
    }

    public static void pintaDatosPersonales() {
        System.out.println(controller.traeUsuario().toString());
        pulsaParaContinuar();
        limpiaPantallas();
    }

    public static void compraDeUnProducto(){
        System.out.println("========= Compra un producto ===========");
        System.out.println("========= Productos digitales ===========");
        for (ProductoDigital productoDigital : controller.verProductosDigitales()){
            System.out.println("********************************************");
            System.out.println("ID: " + productoDigital.getId());
            System.out.println("Nombre: " + productoDigital.getNombre());

        }
        System.out.println();
        System.out.println("========= Productos Físicos ===========");
        for (ProductoFisico productoFisico : controller.verProductosFisicos()){
            System.out.println("********************************************");
            System.out.println("ID: " + productoFisico.getId());
            System.out.println("Nombre: " + productoFisico.getNombre());

        }
        try {
            System.out.print("Dime el id del producto: ");
            int idProducto = Integer.parseInt(sc.nextLine());
            System.out.print("Cuantas unidades de ese producto que quieres añadir: ");
            int cantidad = Integer.parseInt(sc.nextLine());
            if (controller.buscaProductoId(idProducto)){
                if (controller.compruebaStockProducto(idProducto)){
                    if (controller.aniadeCarrito(idProducto, cantidad)) System.out.println("Añadido correctamente.");
                    else System.out.println("No se pudo añadir.");
                }
            }
        }catch (NumberFormatException e){
            System.out.println("Debes introducir un número");
        }
        pulsaParaContinuar();
        limpiaPantallas();
    }


    public static void gestionProductos() {
        int opo = 0;
        do {
            try{
                System.out.print("""
                ==== Bienvenido a la gestion de productos ====
                    1. Comprar un producto.
                    2. Búsquedas de productos.
                    3. Salir.
                    Introduce una opción válida:\s""");
                opo = Integer.parseInt(sc.nextLine());
            }catch (NumberFormatException e){
                System.out.println("Debes introducir un producto");
            }
            switch (opo) {
                case 1:
                    limpiaPantallas();
                    compraDeUnProducto();
                    break;
                case 2:
                    limpiaPantallas();
                    busquedasProductos();
                    break;
                case 3:
                    System.out.println("Saliendo al menu principal.");
                    break;
                default:
                    System.out.println("La opción que has introducida no es correcta.");
            }
        }while (opo != 3);


        
    }

    
    public static void gestionCarrito() {
        int op = 0;
        do {
            try {
                System.out.print("""
                ======= Gestión de carrito =======
                    1. Quitar un producto.
                    2. Ver total del carrito
                    3. Salir
                    Introduce una opción válida:\s""");
                op = Integer.parseInt(sc.nextLine());
            }catch (NumberFormatException e){
                System.out.println("Debes introducir un número");
            }
            switch (op) {
                case 1:
                    limpiaPantallas();
                    quitaProducto();
                    break;
                case 2:
                    limpiaPantallas();
                    verTotalCarrito();
                    break;
                case 3:
                    System.out.println("Saliendo al menu principal.");
                    pulsaParaContinuar();
                    limpiaPantallas();
                    break;
                default:
                    System.out.println("La opción que has elegido no es correcta.");
            }
        }while (op != 3);

        
    }

    private static void verTotalCarrito() {
        System.out.println("EL total del carrito actualmente es: " + controller.verTotalCarrito());
    }

    private static void quitaProducto() {
        System.out.println("========= Tus productos ===========");
        List<Producto> carrito = controller.verCarrito();
        if (carrito.isEmpty()) System.out.println("Aún no has introducido ningún producto al carrito.");
        else{
            for (Producto producto : carrito){
                System.out.println("Nombre: " + producto.getNombre());
                System.out.println("Precio: " + producto.getPrecio());
            }
            System.out.print("Dime el nombre del producto que quieres quitar: ");
            String nombreProducto = sc.nextLine();
            if (controller.quitaProductoCarrito(nombreProducto)) System.out.println("EL producto se ha retirado correctamente.");
            else System.out.println("No se ha podido retirar el producto.");
        }
        pulsaParaContinuar();
        limpiaPantallas();
    }

    public static void busquedasProductos() {
        int op = 0;
        do {
            try {
                System.out.print("""
                ======== Búsquedas de productos ========
                    1. Por texto o palabras clave.
                    2. Por precio.
                    3. Salir.
                    Introduce una opción correcta:\s""");
                op = Integer.parseInt(sc.nextLine());
            }catch (NumberFormatException e){
                System.out.println("Debes introducir un número");
            }
            switch (op) {
                case 1:
                    limpiaPantallas();
                    buscaPorTexto();
                    break;
                case 2:
                    limpiaPantallas();
                    buscaPorPrecio();
                    break;
                case 3:
                    System.out.println("Saliendo al menu principal.");
                    break;
                default:
                    System.out.println("Esa opción no es válida");
            }
        }while (op != 3);

    }

    public static void buscaPorPrecio(){
        try{
            System.out.print("Dime el precio mínimo del producto: ");
            float precioMinimo = Float.parseFloat(sc.nextLine());
            System.out.print("Dime el precio maximo del producto: ");
            float precioMaximo = Float.parseFloat(sc.nextLine());
            for (Producto producto : controller.buscaRangoPrecio(precioMinimo, precioMaximo)){
                System.out.println("Nombre: " + producto.getNombre());
                System.out.println("Precio: " + producto.getPrecio());
                if (producto instanceof ProductoDigital){
                    System.out.println("Licencia: " + ((ProductoDigital) producto).getLicencia());
                    System.out.println("Tamanio descarga: " +  ((ProductoDigital) producto).getTamanioDescarga());
                }

                if (producto instanceof ProductoFisico){
                    System.out.println("Peso:  " + ((ProductoFisico) producto).getPeso());
                    System.out.println("Gastos envío: "+ ((ProductoFisico) producto).getGastosEnvio());
                }
                System.out.println("***********************************");
            }
        }catch (NumberFormatException e){
            System.out.println("Debes introducir un precio (número)");
        }
    }

    public static void buscaPorTexto() {
        System.out.print("Dime el nombre o la palabra clave de ese producto: ");
        String palabra = sc.nextLine();
        System.out.println("Productos que coninciden con su búsqueda: ");
        for (Producto producto : controller.buscaPorTexto(palabra)){
            System.out.println("Nombre: " + producto.getNombre());
            System.out.println("Precio: " + producto.getPrecio());
            if (producto instanceof ProductoDigital){
                System.out.println("Licencia: " + ((ProductoDigital) producto).getLicencia());
                System.out.println("Tamanio descarga: " +  ((ProductoDigital) producto).getTamanioDescarga());
            }

            if (producto instanceof ProductoFisico){
                System.out.println("Peso:  " + ((ProductoFisico) producto).getPeso());
                System.out.println("Gastos envío: "+ ((ProductoFisico) producto).getGastosEnvio());
            }
            System.out.println("***********************************");
        }
    }

    public static void muestraProductos() {
        System.out.println("=========== Productos digitales ===========");
        for (ProductoDigital productoDigital : controller.verProductosDigitales()){
            System.out.println("Nombre: " + productoDigital.getNombre());
            System.out.println("Precio: " + productoDigital.getPrecio());
            System.out.println("*****************************************");
        }

        System.out.println();
        System.out.println("=========== Productos físicos ===========");
        for (ProductoFisico productoFisico : controller.verProductosFisicos()){
            System.out.println("Nombre: " + productoFisico.getNombre());
            System.out.println("Precio: " + productoFisico.getPrecio());
            System.out.println("*****************************************");
        }
    }
}
