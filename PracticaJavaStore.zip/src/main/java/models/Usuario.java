package models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Map;

public class Usuario implements Serializable {
    private int id;
    private String nombre;
    private String email;
    private String password;
    private boolean activo;
    private Carrito carrito;


    public Usuario(String password, int id, String nombre, String email, boolean activo) {
        this.id = id;
        this.nombre = nombre;
        this.email = email;
        this.activo = activo;
        this.password = password;
        this.carrito = new Carrito();
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public Carrito getCarrito() {
        return carrito;
    }

    public void setCarrito(Carrito carrito) {
        this.carrito = carrito;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("\n--------------------------------------------------\n");
        sb.append("                 DATOS DE USUARIO                 \n");
        sb.append("--------------------------------------------------\n");
        sb.append(String.format(" ID       : %d\n", id));
        sb.append(String.format(" Nombre   : %s\n", nombre));
        sb.append(String.format(" Email    : %s\n", email));
        sb.append(String.format(" Activo   : %s\n", activo ? "Sí" : "No"));
        sb.append("--------------------------------------------------\n");
        sb.append(" CARRITO DE COMPRAS:\n");
        sb.append("--------------------------------------------------\n");

        if (carrito != null && carrito.getProductos() != null && !carrito.getProductos().isEmpty()) {
            sb.append(String.format(" %-22s | %-8s | %-10s\n", "Producto", "Cant.", "Precio U."));
            sb.append(" ------------------------------------------------\n");

            for (Map.Entry<Producto, Integer> entry : carrito.getProductos().entrySet()) {
                Producto p = entry.getKey();
                int cantidad = entry.getValue();

                String nombreProd = p.getNombre().length() > 20
                        ? p.getNombre().substring(0, 17) + "..."
                        : p.getNombre();

                sb.append(String.format(" %-22s | %-8d | %-9.2f€\n", nombreProd, cantidad, p.getPrecio()));
            }
        } else {
            sb.append(" (El carrito está vacío)\n");
        }

        sb.append("--------------------------------------------------");

        return sb.toString();
    }
}
