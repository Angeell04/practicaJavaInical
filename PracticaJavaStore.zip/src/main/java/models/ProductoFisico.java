package models;

import java.io.Serializable;

public class ProductoFisico extends Producto implements Serializable {
    private float peso;
    private float gastosEnvio;


    public ProductoFisico(float peso, float gastosEnvio, int id, String nombre, float precio, int stock) {
        super(id, nombre, precio, stock);
        this.peso = peso;
        this.gastosEnvio = gastosEnvio;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public float getGastosEnvio() {
        return gastosEnvio;
    }

    public void setGastosEnvio(float gastosEnvio) {
        this.gastosEnvio = gastosEnvio;
    }
}
