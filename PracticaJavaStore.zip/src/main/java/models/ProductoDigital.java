package models;

import java.io.Serializable;

public class ProductoDigital extends Producto implements Serializable {
    private float tamanioDescarga;
    private String licencia;

    public ProductoDigital(String licencia, float tamanioDescarga, int id, String nombre, float precio, int stock) {
        super(id, nombre, precio, stock);
        this.tamanioDescarga = tamanioDescarga;
        this.licencia = licencia;
    }

    public float getTamanioDescarga() {
        return tamanioDescarga;
    }

    public void setTamanioDescarga(float tamanioDescarga) {
        this.tamanioDescarga = tamanioDescarga;
    }

    public String getLicencia() {
        return licencia;
    }
    public void setLicencia(String licencia) {
        this.licencia = licencia;
    }

}
