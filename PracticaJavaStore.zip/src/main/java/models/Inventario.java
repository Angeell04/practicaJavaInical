package models;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class Inventario implements Serializable {
    private Set<Producto>  productos;

    public Inventario() {
        this.productos = new HashSet<>();
    }

    public Set<Producto> getProductos() {
        return productos;
    }

    public void setProductos(Set<Producto> productos) {
        this.productos = productos;
    }

    public void addProductoFisico(ProductoFisico producto) {
        this.productos.add(producto);
    }

    public void addProductoDigital(ProductoDigital producto) {
        this.productos.add(producto);
    }
}
