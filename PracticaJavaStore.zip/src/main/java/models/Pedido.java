package models;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

public class Pedido implements Serializable {
    private Usuario usuario;
    private int idPedido;
    private LocalDateTime fechaPedido;
    private Map<Producto, Integer> itemsPedido;
    private float total;

    public Pedido(Usuario usuario, int idPedido, LocalDateTime fechaPedido, Map<Producto, Integer> itemsPedido, float total) {
        this.usuario = usuario;
        this.idPedido = idPedido;
        this.fechaPedido = fechaPedido;
        this.itemsPedido = itemsPedido;
        this.total = total;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public LocalDateTime getFechaPedido() {
        return fechaPedido;
    }

    public void setFechaPedido(LocalDateTime fechaPedido) {
        this.fechaPedido = fechaPedido;
    }

    public Map<Producto, Integer> getItemsPedido() {
        return itemsPedido;
    }

    public void setItemsPedido(Map<Producto, Integer> itemsPedido) {
        this.itemsPedido = itemsPedido;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

        sb.append("\n==================================================\n");
        sb.append("                 DETALLE DE PEDIDO                \n");
        sb.append("==================================================\n");
        sb.append(String.format(" ID Pedido : #%d\n", idPedido));
        sb.append(String.format(" Fecha     : %s\n", fechaPedido != null ? fechaPedido.format(formatter) : "N/D"));
        sb.append(String.format(" Cliente   : %s\n", usuario != null ? usuario.getNombre() : "Anonimo"));
        sb.append("--------------------------------------------------\n");
        sb.append(" PRODUCTOS:\n");
        sb.append("--------------------------------------------------\n");

        if (itemsPedido != null && !itemsPedido.isEmpty()) {
            sb.append(String.format(" %-22s | %-8s | %-10s\n", "Producto", "Cant.", "Subtotal"));
            sb.append(" ------------------------------------------------\n");

            for (Map.Entry<Producto, Integer> entry : itemsPedido.entrySet()) {
                Producto p = entry.getKey();
                int cantidad = entry.getValue();
                double subtotal = p.getPrecio() * cantidad;

                String nombreProd = p.getNombre().length() > 20
                        ? p.getNombre().substring(0, 17) + "..."
                        : p.getNombre();

                sb.append(String.format(" %-22s | %-8d | %-9.2f€\n", nombreProd, cantidad, subtotal));
            }
        } else {
            sb.append(" (El carrito esta vacio)\n");
        }

        sb.append("--------------------------------------------------\n");
        sb.append(String.format(" TOTAL A PAGAR : %15.2f€\n", total));
        sb.append("==================================================");

        return sb.toString();
    }
}
