package models;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class GestionUsuarios implements Serializable {
    private Set<Usuario> usuarios;

    public GestionUsuarios() {
        this.usuarios = new HashSet<>();
    }

    public Set<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(Set<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    public void addUsuario(Usuario usuario) {
        this.usuarios.add(usuario);
    }
}
