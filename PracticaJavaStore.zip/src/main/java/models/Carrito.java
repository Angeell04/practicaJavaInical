package models;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class Carrito implements Serializable {

    private Map<Producto, Integer> productos;

    public Carrito() {
        this.productos = new HashMap<Producto, Integer>();
    }

    public Map<Producto, Integer> getProductos() {
        return productos;
    }

    public void setProductos(Map<Producto, Integer> productos) {
        this.productos = productos;
    }

    public boolean addProducto(Producto producto, int cantidad){
        this.productos.put(producto, cantidad);
        return true;
    }

    public void vaciarCarrito(){
        this.productos.clear();
    }


}
