package models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class HistorialPedidos implements Serializable {
    List<Pedido>  pedidos;

    public HistorialPedidos() {
        this.pedidos = new ArrayList<>();
    }

    public List<Pedido> getPedidos() {
        return pedidos;
    }

    public void setPedidos(List<Pedido> pedidos) {
        this.pedidos = pedidos;
    }

    public HistorialPedidos(List<Pedido> pedidos) {
        this.pedidos = pedidos;
    }

    public boolean addPedido(Pedido pedido) {
        return pedidos.add(pedido);
    }

}
