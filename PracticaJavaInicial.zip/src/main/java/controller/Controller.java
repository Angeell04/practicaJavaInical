package controller;

import data.Data;
import models.*;
import persistencia.Persistencia;

import java.io.File;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Controller {
    private Inventario inventario;
    private GestionUsuarios gestionUsuarios;
    private HistorialPedidos historialPedidos;
    private Usuario usuario;

    public Controller() {
        this.inventario = leeInventario();
        this.gestionUsuarios = leeGestionUsuarios();
        this.historialPedidos = leeHistorialPedidos();
        this.usuario = null;
    }

    public boolean login(String usuario, String password) {
        for (Usuario user : gestionUsuarios.getUsuarios()) {
            if (user.getEmail().equals(usuario) && user.getPassword().equals(password)){
                this.usuario = buscaUsuarioId(user.getId());
                this.usuario.setActivo(true);
                return true;
            }
        }

        return false;
    }

    private Usuario buscaUsuarioId(int id) {
        for (Usuario user : gestionUsuarios.getUsuarios()) {
            if (user.getId() == id) return user;
        }
        return null;
    }

    public boolean registro(String nombre, String email, String password) {
        for (Usuario user : gestionUsuarios.getUsuarios()) {
            if (user.getEmail().equals(email)) return false;
        }
        Usuario usuario = new Usuario(password,generaIdAleatorio(),nombre,email,true);
        gestionUsuarios.addUsuario(usuario);
        this.usuario = usuario;
        return Persistencia.guardaGestionUsuarios(gestionUsuarios);
    }

    private int generaIdAleatorio() {
        int idAleatorio = 0;
        do {
            idAleatorio = (int)(Math.random() * 100 + 1);

        }while (compruebaId(idAleatorio));
        return idAleatorio;
    }
    public int generaIdProducto() {
        int idAleatorio = 0;
        do {
            idAleatorio = (int)(Math.random() * 100 + 1);

        }while (compruebaIdProducto(idAleatorio));
        return idAleatorio;
    }

    private boolean compruebaIdProducto(int idAleatorio) {
        for (Producto producto: inventario.getProductos()) {
            if (producto.getId() == idAleatorio) return true;
        }
        return false;
    }


    private boolean compruebaId(int idAleatorio) {
        for (Usuario user : gestionUsuarios.getUsuarios()) {
            if (user.getId() == idAleatorio) return true;
        }
        return false;
    }

    public void darDeBaja() {
        usuario.setActivo(false);
        Persistencia.guardaGestionUsuarios(gestionUsuarios);
    }

    public ArrayList<Usuario> traeUsuariosActivos() {
        ArrayList<Usuario> usuarios = new ArrayList<>();
        for (Usuario user : gestionUsuarios.getUsuarios()) {
            if (user.isActivo()) usuarios.add(user);
        }
        return usuarios;
    }

    public List<ProductoDigital> verProductosDigitales() {
        List<ProductoDigital> lista = new ArrayList<>();
        for (Producto producto: inventario.getProductos()){
            if (producto instanceof ProductoDigital){
                ProductoDigital productoDigital = (ProductoDigital) producto;
                lista.add(productoDigital);
            }
        }
        return lista;
    }

    public List<ProductoFisico> verProductosFisicos() {
        List<ProductoFisico> lista = new ArrayList<>();
        for (Producto producto: inventario.getProductos()){
            if (producto instanceof ProductoFisico){
                ProductoFisico productoFisico = (ProductoFisico) producto;
                lista.add(productoFisico);
            }
        }
        return lista;
    }


    public boolean buscaProductoId(int id) {
        for (Producto producto: inventario.getProductos()){
            if (producto.getId() == id) return true;
        }
        return false;
    }

    public boolean compruebaStockProducto(int idProducto) {
        Producto producto = traeProductoId(idProducto);
        return producto != null &&  producto.getStock() > 0;
    }

    public Producto traeProductoId(int idProducto) {
        for (Producto producto: inventario.getProductos()){
            if (producto.getId() == idProducto) return producto;
        }
        return null;
    }


    public boolean aniadeCarrito(int idProducto, int cantidad) {
        Producto producto = traeProductoId(idProducto);

        // Comprobamos que el producto exista para evitar errores
        if (producto != null) {
            this.usuario.getCarrito().addProducto(producto, cantidad);
            restaCantidadAInventario();
            Persistencia.guardaGestionUsuarios(gestionUsuarios);
        } else {
            return false;
        }
        return true;
    }

    public List<Producto> buscaPorTexto(String texto) {
        List<Producto> lista = new ArrayList<>();
        for (Producto producto: inventario.getProductos()){
            if (producto.getNombre().toUpperCase().contains(texto.toUpperCase())) lista.add(producto);
        }
        return lista;
    }

    public List<Producto> buscaRangoPrecio(float precioMinimo, float precioMaximo) {
        List<Producto> lista = new ArrayList<>();
        for (Producto producto: inventario.getProductos()){
            if (producto.getPrecio() >= precioMinimo && producto.getPrecio() <= precioMaximo) lista.add(producto);
        }
        return lista;
    }

    public List<Producto> verCarrito() {
        List<Producto> lista = new ArrayList<>();
        for (Map.Entry<Producto, Integer> entrada: usuario.getCarrito().getProductos().entrySet()){
             lista.add(entrada.getKey());
        }
        return lista;
    }

    public boolean quitaProductoCarrito(String nombreProducto) {
        Producto productoAQuitar = null;
        int cantidadAQuitar = 0;
        boolean encontrado = false;

        for (Map.Entry<Producto, Integer> entrada : usuario.getCarrito().getProductos().entrySet()) {
            if (entrada.getKey().getNombre().toUpperCase().contains(nombreProducto.toUpperCase())) {
                productoAQuitar = entrada.getKey();
                cantidadAQuitar = entrada.getValue();
                encontrado = true;
                break; // Rompemos el bucle porque ya lo encontramos
            }
        }

        if (encontrado) {
            usuario.getCarrito().getProductos().remove(productoAQuitar);

            for (Producto productoInventario : inventario.getProductos()) {
                if (productoInventario.getId() == productoAQuitar.getId()) {
                    productoInventario.setStock(productoInventario.getStock() + cantidadAQuitar);
                    break;
                }
            }

            // Guardamos los cambios en la persistencia de ambos
            Persistencia.guardaInventario(inventario);
            Persistencia.guardaGestionUsuarios(gestionUsuarios);

            return true;
        }

        return false; // Si no se encontró el producto
    }

    public float verTotalCarrito() {
        float total = 0;
        for (Map.Entry<Producto, Integer> entrada: usuario.getCarrito().getProductos().entrySet()){
            total += entrada.getKey().getPrecio() * entrada.getValue();
        }
        return total;
    }

    public Pedido cierraPedido() {
        if (!hayStockSuficiente()) {
            return null; // Cancelamos el pedido
        }
        restaCantidadAInventario();


        Map<Producto, Integer> copiaProductos = new HashMap<>(this.usuario.getCarrito().getProductos());
        Pedido pedido = new Pedido(this.usuario, generaIdPedido(), LocalDateTime.now(), copiaProductos, verTotalCarrito());

        historialPedidos.addPedido(pedido);
        this.usuario.getCarrito().vaciarCarrito();
        if (Persistencia.guardaGestionUsuarios(gestionUsuarios)){
            if (Persistencia.guardaHistorialPedidos(historialPedidos)) {
                return pedido;
            }
        }
        return null;
    }

    private boolean hayStockSuficiente() {
        for (Map.Entry<Producto, Integer> entrada : usuario.getCarrito().getProductos().entrySet()) {
            Producto productoCarrito = entrada.getKey();
            int cantidadComprada = entrada.getValue();

            for (Producto productoInventario : inventario.getProductos()) {
                if (productoInventario.getId() == productoCarrito.getId()) { // O .equals() si es un objeto
                    // Si el stock real es menor que lo que se quiere comprar
                    if (productoInventario.getStock() < cantidadComprada) {
                        return false; // ¡Falta stock!
                    }
                    break;
                }
            }
        }
        return true; // Todos los productos tienen stock suficiente
    }

    public List<Producto> obtenerProductosSinStock() {
        List<Producto> productosSinStock = new ArrayList<>();

        for (Map.Entry<Producto, Integer> entrada : usuario.getCarrito().getProductos().entrySet()) {
            Producto productoCarrito = entrada.getKey();
            int cantidadComprada = entrada.getValue();

            for (Producto productoInventario : inventario.getProductos()) {
                // Usa .equals() si el ID es un String o Integer, o == si es int primitivo
                if (productoInventario.getId() == productoCarrito.getId()) {
                    // Si el stock del inventario es menor que lo que el usuario quiere comprar
                    if (productoInventario.getStock() < cantidadComprada) {
                        productosSinStock.add(productoCarrito);
                    }
                    break;
                }
            }
        }

        return productosSinStock; // Devuelve la lista (estará vacía si todo tiene stock)
    }

    private void restaCantidadAInventario() {
        for (Map.Entry<Producto, Integer> entrada : usuario.getCarrito().getProductos().entrySet()) {
            Producto producto = entrada.getKey();
            int cantidadComprada = entrada.getValue();
            for (Producto producto1 : inventario.getProductos()){
                if (producto.getId() == producto1.getId()){
                    // Como ya validamos antes, sabemos seguro que no dará negativo
                    int nuevoStock = producto1.getStock() - cantidadComprada;
                    producto1.setStock(nuevoStock);
                    break;
                }
            }
        }
        Persistencia.guardaInventario(inventario);
    }

    private int generaIdPedido() {
        int id = 0;
        do {
            id = (int) (Math.random() * 100 + 1);
        }while(buscaPedidoPorID(id));
        return id;
    }

    private boolean buscaPedidoPorID(int id) {
        for (Pedido pedido : historialPedidos.getPedidos()){
            if (pedido.getIdPedido() == id) return true;
        }
        return false;
    }

    public Usuario traeUsuario() {
        return this.usuario;
    }


    public static Inventario leeInventario() {
        File archivo = new File("src/data/inventario.bin");

        if (!archivo.exists()) {
            Inventario mock = Data.generarInventarioMock();
            Persistencia.guardaInventario(mock); // Lo guarda automáticamente
            return mock;
        }

        return Persistencia.leeInventario();
    }

    public static GestionUsuarios leeGestionUsuarios() {
        File archivo = new File("src/data/gestion.bin");

        if (!archivo.exists()) {
            GestionUsuarios mock = Data.generarGestionUsuariosMock();
            Persistencia.guardaGestionUsuarios(mock); // Lo guarda automáticamente
            return mock;
        }

       return Persistencia.leeGestionUsuarios();
    }

    public static HistorialPedidos leeHistorialPedidos() {
        File archivo = new File("src/data/historial.bin");

        if (!archivo.exists()) {
            HistorialPedidos mock = Data.generarHistorialMock();
            Persistencia.guardaHistorialPedidos(mock); // Lo guarda automáticamente
            return mock;
        }

        return Persistencia.leeHistorialPedidos();
    }

    public boolean logAdmin(String email, String contrasenia) {
        if (email.toUpperCase().equals("ADMIN") && contrasenia.toUpperCase().equals("ADMIN")) {
            for (Usuario usuario : gestionUsuarios.getUsuarios()) {
                if (login(email, contrasenia)) {
                    this.usuario = buscaUsuarioId(usuario.getId());
                    return true;
                }
            }
        }
        return false;
    }

    public List<Pedido> verPedidos() {
        return historialPedidos.getPedidos();
    }

    public boolean introducirProductoDigital(String licencia, float tamanioDescarga, String nombre, float precio, int stock ) {
        ProductoDigital producto = new ProductoDigital(licencia, tamanioDescarga, generaIdProducto(), nombre, precio, stock);
        inventario.getProductos().add(producto);
        return Persistencia.guardaInventario(inventario);
    }

    public boolean introducirProductoFisico(float peso, float gastosEnvio, String nombre, float precio, int stock) {
        ProductoFisico productoFisico = new ProductoFisico(peso, gastosEnvio, generaIdProducto(), nombre, precio, stock);
        inventario.getProductos().add(productoFisico);
        return Persistencia.guardaInventario(inventario);
    }

    public boolean quitaProductoInventatirio(String producto) {
        for (Producto producto1 : inventario.getProductos()){
            if (producto.equalsIgnoreCase(producto1.getNombre())){
                inventario.getProductos().remove(producto1);
                return Persistencia.guardaInventario(inventario);
            }
        }
        return false;
    }
}

